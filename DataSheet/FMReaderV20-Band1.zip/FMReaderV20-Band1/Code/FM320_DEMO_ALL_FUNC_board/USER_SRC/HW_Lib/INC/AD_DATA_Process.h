#ifndef  _AD_DATA_Process_H
#define  _AD_DATA_Process_H
#include "stm32f10x_lib.h"




extern vu8 AD_ON; 






























#endif